/*using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.IO.Ports;*/
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.IO.Ports;
using System.Collections;

using log4net;
using log4net.Config;


namespace DemoMultipagos
{
    public partial class Form1 : Form
    {        
        Multipagos2V10.LeeBandaChip leemp2 = null;

        public Form1()
        {

            InitializeComponent();

            leemp2 = new Multipagos2V10.LeeBandaChip();

            string banderaLlave = leemp2.banderaLLave();

            if (leemp2.getMensaje() != null && leemp2.getMensaje().Length > 0)
            {
                MessageBox.Show(leemp2.getMensaje());
            }

            System.Console.WriteLine("banderaLlave: -->" + banderaLlave + "<--");

            if (banderaLlave.Equals("1"))
            {

                MessageBox.Show("Sincronizando pinpad, espere un momento \nPor favor no deconecte la terminal");
                string res = "";
                leemp2.llave();
                tagEMV.Text = leemp2.getTagEMV();

                /*res = leemp2.compra("",
                                 "",
                                 Convert.ToInt32(nivel1.Text),
                                 servicio.Text,
                                 Convert.ToInt32(moneda.Text),
                                 "",
                                 "",
                                 "",
                                 "",
                                 "",
                                 "",
                                 "",
                                 "",
                                 Convert.ToInt32(entidad.Text),
                                 "",
                                 "",
                                 "",
                                 "",
                                 "",
                                 mail.Text,
                                 "CARGA",
                                 "",
                                 tagEMV.Text,
                                 "",
                                 "",
                                 "");*/


                Console.WriteLine("respuesta: " + res);

                String tokenET = "";
                if (res != null)
                {                    
                    Hashtable hrespuesta = leemp2.mapea(res);
                    tokenET = (string)hrespuesta["tokenET"];

                    if (tokenET == null)
                    {
                        tokenET = "";
                    }
                }

                leemp2.carga(tokenET);

                MessageBox.Show(leemp2.getMensaje());
            }
        }

        private void enviar_Click(object sender, EventArgs e)
        {
            //System.Console.WriteLine("Inicio");
            
            System.Console.WriteLine("T2: " + leemp2.encriptaRijndael(feccha.Text));
            System.Console.WriteLine("tracj2: " + leemp2.encriptaRijndael(track2.Text));
            System.Console.WriteLine("tarjeta : -->" + leemp2.encriptaRijndael(tarjeta.Text) + "<--");
            System.Console.WriteLine("Fin");

            string digest = leemp2.encriptaHmac(secuencia.Text + referencia.Text + importe.Text + cvv2.Text);
            System.Console.WriteLine("digest:" + secuencia.Text + referencia.Text + importe.Text + cvv2.Text);
            System.Console.WriteLine("TRANSACCION:" + transaccion.Text);
            string digestVal = "";//digest.Text;
            string res = "";
            if (transaccion.Text.Equals("1"))
            {
                System.Console.WriteLine("ENTRO AQUI");

                
                res = leemp2.compra(secuencia.Text, 
                                    referencia.Text, 
                                    Convert.ToInt32(nivel1.Text), 
                                    servicio.Text, 
                                    Convert.ToInt32(moneda.Text), 
                                    importe.Text, 
                                    titular.Text, 
                                    leemp2.encriptaRijndael(tarjeta.Text),
                                    digest,         
                                    "",             
                                    "",             
                                    Convert.ToInt32(entidad.Text), 
                                    tpTarjeta.Text, 
                                    val_19.Text,    
                                    periodo.Text,   
                                    mail.Text, 
                                    "PAGO", 
                                    tagEMV.Text,
                                    2); 
            }
            else if (transaccion.Text.Equals("8"))
            {
                //res = leemp2.consulta(Convert.ToInt32(entidad.Text), 
                //                      Convert.ToInt32(nivel1.Text), 
                //                      Convert.ToInt32(moneda.Text), 
                //                      Convert.ToInt32(servicio.Text), 
                //                      secuencia.Text, 
                //                      referencia.Text, 
                //                      importe.Text,
                //                      leemp2.encriptaRijndael(tarjeta.Text),
                //                      "", 
                //                      "", 
                //                      digestVal, 
                //                      "1", 
                //                      ingreso.Text, 
                //                      "CONSULTA", 
                //                      mail.Text, 
                //                      titular.Text, 
                //                      "",
                //                      tag5F34.Text, 
                //                      tagEMV.Text, 
                //                      flag.Text, 
                //                      tag9F26.Text, 
                //                      tag9F27.Text,
                //                      0,
                //                      "");
            }
            else if (transaccion.Text.Equals("2"))
            {
                res = leemp2.cancelacion(secuencia.Text, 
                                         referencia.Text, 
                                         Convert.ToInt32(nivel1.Text), 
                                         servicio.Text, 
                                         Convert.ToInt32(moneda.Text), 
                                         importe.Text, 
                                         titular.Text, 
                                         leemp2.encriptaRijndael(tarjeta.Text), 
                                         digestVal, 
                                         Convert.ToInt32(entidad.Text), 
                                         tpTarjeta.Text, 
                                         val_19.Text, 
                                         periodo.Text, 
                                         mail.Text, 
                                         "CANCELACION",
                                         tagEMV.Text,                                       
                                         autorizacion.Text);
            }

            
            if (res != null)
            {
                Console.WriteLine("---------------------------");
                Console.WriteLine(res);
                Console.WriteLine("---------------------------");
                 
                string criptograma = "";
                string script = "";
                string aut = "";
                string con = "";
                string llave = "";
                string bines = "";
                string cdRespuesta = "";
                string tokenET = "";

                Hashtable hrespuesta = leemp2.mapea(res);

                aut = (string)hrespuesta["autorizacion"];
                script = (string)hrespuesta["script"];
                criptograma = (string)hrespuesta["tag91"];
                con = (string)hrespuesta["consecutivo"];
                llave = (string)hrespuesta["llave"];
                bines = (string)hrespuesta["bines"];
                cdRespuesta = (string)hrespuesta["cdRespuesta"];
                tokenET = (string)hrespuesta["tokenET"];

                if (aut == null || aut.Length == 0)
                    aut = "000000";

                if (criptograma == null)
                    criptograma = "";

                if (script == null)
                    script = "";

                if (llave == null)
                {
                    llave = "";
                }

                //leemp2.termina(aut, criptograma, script, cdRespuesta, 1, llave, bines, tokenET, 0);

                autorizacion.Text = aut;
                consecutivo.Text = con;

                if (leemp2.getMensaje() != "")
                {
                    MessageBox.Show(leemp2.getMensaje());
                }else{

                    if (llave.Equals("2"))
                    {
                        //
                        MessageBox.Show("Sincronizando pinpad, espere un momento \nPor favor no deconecte la terminal");
                        res = "";
                        leemp2.llave();
                        tagEMV.Text = leemp2.getTagEMV();
                        res = leemp2.compra("",
                                            "",
                                            Convert.ToInt32(nivel1.Text),
                                            servicio.Text,
                                            Convert.ToInt32(moneda.Text),
                                            "", // importe
                                            "", // titular
                                            "", //val_3
                                            digest, // val_6
                                            "", // val_11
                                            "", // val_12
                                            Convert.ToInt32(entidad.Text),
                                            "", // val_16
                                            "",  // val_19
                                            "", // val_20
                                            mail.Text,
                                            "CARGA",
                                            tagEMV.Text,
                                            2); //applabel

                        Console.WriteLine("respuesta: " + res);
                        
                        if (res != null)
                        {
                            hrespuesta = leemp2.mapea(res);
                            tokenET = (string)hrespuesta["tokenET"];

                            if (tokenET == null)
                            {
                                tokenET = "";
                            }
                        }

                        leemp2.carga(tokenET);
                        MessageBox.Show(leemp2.getMensaje());

                        //
                    }
                   }
            }

            MessageBox.Show(res);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            bool respuesta = false;            
            string digest = leemp2.encriptaHmac(secuencia.Text + referencia.Text + importe.Text + cvv2.Text);

            System.Console.WriteLine("secuencia     -->" + secuencia.Text + "<--");
            System.Console.WriteLine("referencia    -->" + referencia.Text + "<--");
            System.Console.WriteLine("entidad       -->" + entidad.Text + "<--");
            System.Console.WriteLine("val1          -->" + nivel1.Text + "<--");
            System.Console.WriteLine("servicio      -->" + servicio.Text + "<--");
            System.Console.WriteLine("titular       -->" + titular.Text + "<--");
            System.Console.WriteLine("importe       -->" + importe.Text + "<--");
            System.Console.WriteLine("tarjeta       -->" + leemp2.encriptaRijndael(tarjeta.Text) + "<--");
            System.Console.WriteLine("cdSeguridad   -->" + leemp2.encriptaRijndael(cvv2.Text) + "<--");
            System.Console.WriteLine("digest        -->" + digest + "<--");
            System.Console.WriteLine("mail          -->" + mail + "<--");
            System.Console.WriteLine("telefono      -->" + "" + "<--");
            System.Console.WriteLine("nombre        -->" + "" + "<--");
            System.Console.WriteLine("apellidos     -->" + "" + "<--");
            System.Console.WriteLine("c�digo Postal -->" + "" + "<--");
            System.Console.WriteLine("direcci�n     -->" + "" + "<--");
            System.Console.WriteLine("track1        -->" + leemp2.encriptaRijndael(track1.Text) + "<--");
            System.Console.WriteLine("track2        -->" + leemp2.encriptaRijndael(track2.Text) + "<--");
            System.Console.WriteLine("val_19        -->" + val_19.Text + "<--");
            System.Console.WriteLine("val_20        -->" + periodo.Text + "<--");
            System.Console.WriteLine("moneda        -->" + moneda.Text + "<--");
            System.Console.WriteLine("tagsEMV       -->" + tagEMV.Text + "<--");
            System.Console.WriteLine("tagsE1        -->" + tagE1.Text + "<--");
            System.Console.WriteLine("serie         -->" + leemp2.getNumeroSerie() + "<--");

            respuesta = leemp2.compraAmex( secuencia.Text, 
                                           referencia.Text, 
                                           Convert.ToInt32(entidad.Text), 
                                           Convert.ToInt32(nivel1.Text), 
                                           servicio.Text, 
                                           titular.Text, 
                                           importe.Text, 
                                           leemp2.encriptaRijndael(tarjeta.Text),
                                           leemp2.encriptaRijndael(cvv2.Text), 
                                           digest,
                                           correo.Text,
                                           telefono.Text ,
                                           nombre.Text,
                                           apellidos.Text,
                                           cdPostal.Text ,
                                           direccion.Text,
                                           leemp2.encriptaRijndael(track1.Text), 
                                           leemp2.encriptaRijndael(track2.Text), 
                                           Convert.ToInt32(val_19.Text), 
                                           Convert.ToInt32(periodo.Text), 
                                           Convert.ToInt32(moneda.Text),
                                           tagEMV.Text,
                                           tagE1.Text,
                                           mail.Text,
                                           leemp2.getNumeroSerie());


            if (respuesta)
            {

                //string criptograma = olee.getCripograma();
                string script = leemp2.getScript();
                string autorizacion = leemp2.getAutorizacion();

                System.Console.WriteLine("pagare:" + leemp2.getPagare());
                System.Console.WriteLine("script: " + script);
                //System.Console.WriteLine("criptograma: " + criptograma );
                System.Console.WriteLine("autorizacion: " + autorizacion);
                System.Console.WriteLine("Imprimir: " + leemp2.isImprimir());
                System.Console.WriteLine("mensaje: " + leemp2.getMensaje());
                System.Console.WriteLine("mensaje: " + leemp2.getMensajeError());

                if (autorizacion.Equals(""))
                    autorizacion = "000000";

                //olee.terminaTransaccion(autorizacion, criptograma, script);
                leemp2.termina(autorizacion, leemp2.getCriptograma(), leemp2.getScript(), leemp2.getCodigoRespuesta(), mdoLectura.Text, "0", "0", "", 0);

                leemp2.imprimirComercio(leemp2.getPagare(), "PDFCreator", 0, 255, 32, 49);
            }
            else
            {
                
                string autorizacion = leemp2.getAutorizacion();
                if (autorizacion.Equals(""))
                    autorizacion = "000000";

                leemp2.termina(autorizacion, leemp2.getCriptograma(), leemp2.getScript(), leemp2.getCodigoRespuesta(), mdoLectura.Text, "0", "0", "", 0);
                MessageBox.Show(leemp2.getMensaje());
            }
            //else
                //leemp2.terminaTransaccion("000000", "", "");
        }

        private void tarjeta_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            System.Console.WriteLine("entidad       -->" + entidad.Text + "<--");
            System.Console.WriteLine("nivel1        -->" + nivel1.Text + "<--");
            System.Console.WriteLine("moneda        -->" + moneda.Text + "<--");
            System.Console.WriteLine("servicio      -->" + servicio.Text + "<--");
            System.Console.WriteLine("autorizacion  -->" + autorizacion.Text + "<--");
            System.Console.WriteLine("consecutivo   -->" + consecutivo.Text + "<--");
            System.Console.WriteLine("origen   -->" + origen.Text + "<--");

            bool respuesta = leemp2.cancelaAmex(Convert.ToInt32(entidad.Text), 
                                         Convert.ToInt32(nivel1.Text), 
                                         Convert.ToInt32(moneda.Text), 
                                         servicio.Text, 
                                         Convert.ToInt32(autorizacion.Text), 
                                         Convert.ToInt32(consecutivo.Text),
                                         origen.Text);

            if (respuesta)
            {
                leemp2.imprimirComercio(leemp2.getPagare(), "PDFCreator", 0, 255, 32, 49);
                Console.WriteLine(leemp2.getPagare());
            }
            else
            {
                MessageBox.Show(leemp2.getMensaje());
            }
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (transaccion.Text.Equals("8"))
            {
                leemp2.lee(importe.Text, 3, Int32.Parse(moneda.Text), true);
            }else{
                leemp2.lee(importe.Text, 3, Int32.Parse(moneda.Text), false);
            }           
            
            if (leemp2.getMensaje().Equals(""))
            {
                tarjeta.Text = leemp2.getNumTarjeta();
                titular.Text = leemp2.getName();
                track1.Text = leemp2.getTrack1();
                track2.Text = leemp2.getTrack2();
                tag9F27.Text = leemp2.getTag9F27();
                tagEMV.Text = leemp2.getTagEMV();
                tagE1.Text = leemp2.getTagE1();
                plataforma.Text = leemp2.getPlataforma();
                mdoLectura.Text = leemp2.getMdoLectura();


                cvv2.Text = leemp2.getCvv2();
                if (leemp2.getPlataforma() != null && leemp2.getPlataforma().Equals("1"))
                {
                    serie.Text = leemp2.getNumeroSerie();
                }        

                System.Console.WriteLine("demo tarjeta -->" + leemp2.getNumTarjeta() + "<--");
                System.Console.WriteLine("demo titular -->" + leemp2.getName() + "<--");
                System.Console.WriteLine("demo track1 -->" + leemp2.getTrack1() + "<--");
                System.Console.WriteLine("demo track2 -->" + leemp2.getTrack2() + "<--");
                System.Console.WriteLine("demo TagEMV() -->" + leemp2.getTagEMV() + "<--");
                System.Console.WriteLine("demo cvv2 -->" + leemp2.getCvv2() + "<--");
                System.Console.WriteLine("demo plataforma -->" + leemp2.getPlataforma() + "<--");
                System.Console.WriteLine("demo 9F27 -->" + leemp2.getTag9F27() + "<--");
                System.Console.WriteLine("demo 5F34 -->" + leemp2.getTagE1() + "<--");
                System.Console.WriteLine("demo serie -->" + leemp2.getNumeroSerie() + "<--");
                
            }
            else
            {
                System.Console.WriteLine("demo error -->" + leemp2.getMensajeError() + "<--");
                System.Console.WriteLine("demo error -->" + leemp2.getMensaje() + "<--");

                MessageBox.Show(leemp2.getMensaje() + leemp2.getMensajeError());
            }
        }

        private void Limpiar_Click(object sender, EventArgs e)
        {
            tarjeta.Text = "";
            feccha.Text = "";
            titular.Text = "";
            track1.Text = "";
            track2.Text = "";
            tagE1.Text = "";
            tag9F26.Text = "";
            tag9F27.Text = "";
            tagEMV.Text = "";
            flag.Text = "";
            plataforma.Text = "";
            autorizacion.Text = "";
            aid.Text = "";
            alabel.Text = "";

            /*string xml = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\n" +
                         "<amex-response-envelope version=\"1.0\">\n" +
                         "<amex-response>\n" +
                         "<param name=\"imprimir\" value=\"SI\"/>\n" +
                         "<param name=\"comercio\" value=\"MEDICA SUR\"/>\n" +
                         "<param name=\"direccion\" value=\"1200 PROL PASEO DE LA REFORMA, MEXICO, CP 05349\"/>\n" +
                         "<param name=\"afiliacion\" value=\"9355272643\"/>\n" +
                         "<param name=\"serie\" value=\"9355272643\"/>\n" +
                         "<param name=\"fhTransaccion\" value=\"01mar13\"/>\n" +
                         "<param name=\"hora\" value=\"13:35\"/>\n" +
                         "<param name=\"tarjeta\" value=\"***********0001\"/>\n" +
                         "<param name=\"fhVencimiento\" value=\"1215\"/>\n" +
                         "<param name=\"operacion\" value=\"COMPRA\"/>\n" +
                         "<param name=\"monto\" value=\"224.00\"/>\n" +
                         "<param name=\"ingreso\" value=\"I@1\"/>\n" +
                         "<param name=\"autorizacion\" value=\"152971\"/>\n" +
                         "<param name=\"consecutivo\" value=\"0000011165\"/>\n" +
                         "<param name=\"firma\" value=\"_________________________\"/>\n" +
                         "<param name=\"titular\" value=\"AN AEIPS 10\"/>\n" +
                         "<param name=\"criptograma\" value=\"03315D6A12CF4D703030\"/>\n" +
                         "<param name=\"script\" value=\"727C9F1804C0000000862504DA8E00200000000000000000420141035E031F020000000000000000D48C66EB3BD429C1862504DA8E00200000000000000000420141035E031F020000000000000000D48C66EB3BD429C1862504DA8E00200000000000000000420141035E031F020000000000000000D48C66EB3BD429C1\"/>\n" +
                         "</amex-response>\n" +
                         "</amex-response-envelope>\n";
            Hashtable h = lee.mapea(xml);


            System.Console.WriteLine(h.ContainsKey("autorizacion"));
            System.Console.WriteLine(h.Contains("autorizacion"));
            System.Console.WriteLine((string)h["autorizacion"]);*/


            /*
            System.Console.WriteLine("fecha: " + "1216");
            System.Console.WriteLine("fecha: " + lee.encriptaRijndael("1216"));


            System.Console.WriteLine("fecha: " + "1234");
            System.Console.WriteLine("fecha: " + lee.encriptaRijndael("1234"));

            System.Console.WriteLine("fecha: " + "4444");
            System.Console.WriteLine("fecha: " + lee.encriptaRijndael("4444"));*/

            /*string s = lee.encriptaRijndael("356999001008221");            
            string n = lee.encriptaRijndael("3569990010082212");
            string r = lee.encriptaRijndael("35699900100822123");
            string f = lee.encriptaRijndael("1215");

            System.Console.WriteLine("r: -->" + r + "<--");

            System.Console.WriteLine("s: " + s.Length);
            System.Console.WriteLine("n: " + n.Length);
            System.Console.WriteLine("f: " + f.Length);
            System.Console.WriteLine("r: " + r.Length);*/


            //System.Console.WriteLine("tarjeta_s: " + lee.desencriptaRijndael(s));            
            //System.Console.WriteLine("tarjeta_n: " + lee.desencriptaRijndael(n));
            //System.Console.WriteLine("fecha: " + lee.desencriptaRijndael(f));
            //System.Console.WriteLine("fecha: " + lee.desencriptaRijndael(r));

            //System.Console.WriteLine("fecha: ____________________________");
            /*System.Console.WriteLine("tarjeta: " + "356999001008221");
            System.Console.WriteLine("tarjeta: " + lee.encriptaRijndael("356999001008221"));
            System.Console.WriteLine("tarjeta: " + lee.desencriptaRijndael(lee.encriptaRijndael("356999001008221")));*/

            //System.Console.WriteLine("------------------ SELENE -----------------");

        }

        private void button5_Click(object sender, EventArgs e)
        {
            //string x =lee.encriptaRijndael(trac2.Text);
            //string y = lee.encriptaHmac(referencia.Text + secuencia.Text + importe.Text);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //string x = lee.getBinesDeLealtad("","");
            //MessageBox.Show(x);

            //string x = lee.getBinesDeLealtad("snochebuena@adquira.com.mx", "CONSULTA");
            //System.Console.WriteLine(x);
            //MessageBox.Show(x + "-->" + x.Length);


            //string x = lee.encriptaHmac(referencia.Text + secuencia.Text + importe.Text);
            //string x = lee.encriptaHmac("123456789012345678901234567890" + "123456789012345678901234567890" + "1234567890.00");
            //string x = lee.encriptaHmac("selene");
            //MessageBox.Show(x.Length + "-->" + x + "-->" + "123456789012345678901234567890" + "123456789012345678901234567890" + "1234567890.00");
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            /*string res = lee.getStatus(Convert.ToInt32(entidad.Text), 
                                       Convert.ToInt32(nivel1.Text), 
                                       Convert.ToInt32(moneda.Text), 
                                       Convert.ToInt32(servicio.Text), 
                                       secuencia.Text, 
                                       referencia.Text, 
                                       mail.Text, "STATUS", "1");*/

            //MessageBox.Show(res);
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            /*string respuesta = null;

            
            respuesta = lee.devolucion( Convert.ToInt32(entidad.Text),
                        Convert.ToInt32(nivel1.Text), 
                        Convert.ToInt32(moneda.Text),
                        servicio.Text,
                        referencia.Text,
                        autorizacion.Text,
                        importe.Text, 
                        mail.Text, 
                        "DEVOLUCION",
                        secuencia.Text);
             

            //lee.terminaTransaccion("123456");

            System.Console.WriteLine(respuesta);
            //MessageBox.Show(respuesta);*/
        }

        private void label26_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click_2(object sender, EventArgs e)
        {
            //lee.terminaTransaccion(autorizacion.Text,"","");
            /*if (autorizacion.Text.Length == 0)
                autorizacion.Text = "000000";
            lee.terminaTransaccion(autorizacion.Text, "", "");
            lee.terminaTransaccion(autorizacion.Text, "", "");
            lee.terminaTransaccion(autorizacion.Text, "", "");*/

            //leemp2.termina("123456", "", "", "00", 1, "0", "0", "", 0);

            /*ILog log = null;            
            log4net.Config.XmlConfigurator.Configure();
            log = log4net.LogManager.GetLogger("log4Net");
            log.Info("---->SELENE NOCHEBUENA ROJO<----");*/

            leemp2.termina("000000", "", "", "49", mdoLectura.Text, "0", "0", "", 0);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            /*string xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
                         "<transacciones registros=\"2\">" +
                         "<registro >" +
	                     "<entidad>10710</entidad>" +
	                     "<nivel1>38272</nivel1>" +
	                     "<nivel2>0</nivel2>" +
	                     "<servicio>1196</servicio>" +
                         "<referencia>2013061101</referencia>" +
	                     "<secuencia>01</secuencia>" +
                         "<autorizacion>adq347</autorizacion>" +
                         "</registro>" +
                         "<registro numero=\"2\">" +
	                     "<entidad>10700</entidad>" +
	                     "<nivel1>0</nivel1>" +
	                     "<nivel2>0</nivel2>" +
	                     "<servicio>99</servicio>" +
	                     "<referencia>2013060702</referencia>" +
	                     "<secuencia>02</secuencia>" +
                         "<autorizacion>adq456</autorizacion>" +
                         "</registro>" +	
                         "</transacciones>";

            System.Console.WriteLine(lee.enviar(xml, entidad.Text, mail.Text));
            */
            
        }

        private void button8_Click(object sender, EventArgs e)
        {
        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            /*String bines = lee.getBinesDeLealtad(mail.Text, "CONSULTA");
            MessageBox.Show(bines);
            System.Console.WriteLine(bines);*/
        }

        private void button9_Click(object sender, EventArgs e)
        {
            String res = "";

            MessageBox.Show("Espere un momento inicia la sincronizacion de la pinpad \nPor favor no desconecte la terminal");
            leemp2.llave();

            tagEMV.Text = leemp2.getTagEMV();

            Console.WriteLine("rtagEMV.Text: " + tagEMV.Text);

            res = leemp2.compra(secuencia.Text,
                                referencia.Text,
                                Convert.ToInt32(nivel1.Text),
                                servicio.Text,
                                Convert.ToInt32(moneda.Text),
                                "",     // importe
                                "",     // titular
                                "",     // val_3
                                "",     // val_6
                                "",     // val_11
                                "",     // val_12
                                Convert.ToInt32(entidad.Text),
                                "",     // val_16
                                "",     // val_19
                                "",     // val_20
                                mail.Text,
                                "CARGA",
                                tagEMV.Text,
                                2);

            Console.WriteLine("respuesta_CARGA: " +  res);
            string tokenEX = "";

            if (res != null)
            {
                Hashtable hrespuesta = leemp2.mapea(res);

                tokenEX = (string)hrespuesta["tokenEX"];

                if (tokenEX == null)
                {
                    tokenEX = "";                    
                }                
            }
            else
            {
                tokenEX = "";
            }

            Console.WriteLine("respuesta_CARGA: " + res);
            leemp2.carga(tokenEX);
            MessageBox.Show(leemp2.getMensaje());
        }

        private void button10_Click(object sender, EventArgs e)
        {
            leemp2.actualiza();
            MessageBox.Show(leemp2.getMensaje());
        }
    }
}