﻿using System.Drawing;
namespace DemoMultipagos
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.entidad = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.nivel1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.servicio = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.moneda = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.importe = new System.Windows.Forms.TextBox();
            this.ltitular = new System.Windows.Forms.Label();
            this.titular = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tarjeta = new System.Windows.Forms.TextBox();
            this.lfecha = new System.Windows.Forms.Label();
            this.feccha = new System.Windows.Forms.TextBox();
            this.lCVV2 = new System.Windows.Forms.Label();
            this.cvv2 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.lmail = new System.Windows.Forms.Label();
            this.mail = new System.Windows.Forms.TextBox();
            this.enviar = new System.Windows.Forms.Button();
            this.lsecuencia = new System.Windows.Forms.Label();
            this.secuencia = new System.Windows.Forms.TextBox();
            this.lreferencia = new System.Windows.Forms.Label();
            this.referencia = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.track1 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.track2 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.val_19 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.periodo = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.transaccion = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.ingreso = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.autorizacion = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.tagE1 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.flag = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.tag9F26 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.tag9F27 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.label24 = new System.Windows.Forms.Label();
            this.consecutivo = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.Limpiar = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.plataforma = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.tpTarjeta = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.digest = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.aid = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.alabel = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.origen = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.tagEMV = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.serie = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.mdoLectura = new System.Windows.Forms.TextBox();
            this.correo = new System.Windows.Forms.TextBox();
            this.telefono = new System.Windows.Forms.TextBox();
            this.nombre = new System.Windows.Forms.TextBox();
            this.apellidos = new System.Windows.Forms.TextBox();
            this.direccion = new System.Windows.Forms.TextBox();
            this.cdPostal = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(10, 102);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Id. Cliente";
            // 
            // entidad
            // 
            this.entidad.BackColor = System.Drawing.Color.White;
            this.entidad.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.entidad.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.entidad.Location = new System.Drawing.Point(92, 95);
            this.entidad.Name = "entidad";
            this.entidad.Size = new System.Drawing.Size(52, 20);
            this.entidad.TabIndex = 1;
            this.entidad.Text = "10710";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(43, 127);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Caja";
            // 
            // nivel1
            // 
            this.nivel1.BackColor = System.Drawing.Color.White;
            this.nivel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nivel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.nivel1.Location = new System.Drawing.Point(92, 127);
            this.nivel1.Name = "nivel1";
            this.nivel1.Size = new System.Drawing.Size(27, 20);
            this.nivel1.TabIndex = 3;
            this.nivel1.Text = "38272";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(22, 163);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Servicio";
            // 
            // servicio
            // 
            this.servicio.BackColor = System.Drawing.Color.White;
            this.servicio.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.servicio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.servicio.Location = new System.Drawing.Point(92, 156);
            this.servicio.Name = "servicio";
            this.servicio.Size = new System.Drawing.Size(27, 20);
            this.servicio.TabIndex = 5;
            this.servicio.Text = "1196";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(348, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(146, 50);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(27, 213);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Moneda";
            // 
            // moneda
            // 
            this.moneda.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.moneda.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.moneda.Location = new System.Drawing.Point(92, 206);
            this.moneda.Name = "moneda";
            this.moneda.Size = new System.Drawing.Size(30, 20);
            this.moneda.TabIndex = 8;
            this.moneda.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(28, 246);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Importe";
            // 
            // importe
            // 
            this.importe.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.importe.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.importe.Location = new System.Drawing.Point(93, 242);
            this.importe.Name = "importe";
            this.importe.Size = new System.Drawing.Size(52, 20);
            this.importe.TabIndex = 10;
            this.importe.Text = "9.00";
            // 
            // ltitular
            // 
            this.ltitular.AutoSize = true;
            this.ltitular.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ltitular.ForeColor = System.Drawing.Color.White;
            this.ltitular.Location = new System.Drawing.Point(266, 92);
            this.ltitular.Name = "ltitular";
            this.ltitular.Size = new System.Drawing.Size(43, 13);
            this.ltitular.TabIndex = 11;
            this.ltitular.Text = "Titular";
            // 
            // titular
            // 
            this.titular.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titular.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.titular.Location = new System.Drawing.Point(330, 89);
            this.titular.Name = "titular";
            this.titular.Size = new System.Drawing.Size(183, 20);
            this.titular.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(264, 131);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "Tarjeta";
            // 
            // tarjeta
            // 
            this.tarjeta.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tarjeta.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.tarjeta.Location = new System.Drawing.Point(330, 127);
            this.tarjeta.Name = "tarjeta";
            this.tarjeta.Size = new System.Drawing.Size(144, 20);
            this.tarjeta.TabIndex = 14;
            this.tarjeta.TextChanged += new System.EventHandler(this.tarjeta_TextChanged);
            // 
            // lfecha
            // 
            this.lfecha.AutoSize = true;
            this.lfecha.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lfecha.ForeColor = System.Drawing.Color.White;
            this.lfecha.Location = new System.Drawing.Point(240, 161);
            this.lfecha.Name = "lfecha";
            this.lfecha.Size = new System.Drawing.Size(76, 13);
            this.lfecha.TabIndex = 15;
            this.lfecha.Text = "Vencimiento";
            // 
            // feccha
            // 
            this.feccha.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.feccha.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.feccha.Location = new System.Drawing.Point(332, 159);
            this.feccha.Name = "feccha";
            this.feccha.Size = new System.Drawing.Size(41, 20);
            this.feccha.TabIndex = 16;
            // 
            // lCVV2
            // 
            this.lCVV2.AutoSize = true;
            this.lCVV2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lCVV2.ForeColor = System.Drawing.Color.White;
            this.lCVV2.Location = new System.Drawing.Point(274, 196);
            this.lCVV2.Name = "lCVV2";
            this.lCVV2.Size = new System.Drawing.Size(38, 13);
            this.lCVV2.TabIndex = 17;
            this.lCVV2.Text = "CVV2";
            // 
            // cvv2
            // 
            this.cvv2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cvv2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.cvv2.Location = new System.Drawing.Point(332, 196);
            this.cvv2.Name = "cvv2";
            this.cvv2.PasswordChar = '*';
            this.cvv2.Size = new System.Drawing.Size(43, 20);
            this.cvv2.TabIndex = 18;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(255, 229);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 13);
            this.label7.TabIndex = 19;
            // 
            // lmail
            // 
            this.lmail.AutoSize = true;
            this.lmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lmail.ForeColor = System.Drawing.Color.White;
            this.lmail.Location = new System.Drawing.Point(9, 414);
            this.lmail.Name = "lmail";
            this.lmail.Size = new System.Drawing.Size(30, 13);
            this.lmail.TabIndex = 22;
            this.lmail.Text = "Mail";
            // 
            // mail
            // 
            this.mail.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mail.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.mail.Location = new System.Drawing.Point(60, 410);
            this.mail.Name = "mail";
            this.mail.Size = new System.Drawing.Size(183, 20);
            this.mail.TabIndex = 23;
            this.mail.Text = "ramon.padilla@alsea.com.mx";
            // 
            // enviar
            // 
            this.enviar.BackColor = System.Drawing.Color.White;
            this.enviar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.enviar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enviar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.enviar.Location = new System.Drawing.Point(32, 613);
            this.enviar.Name = "enviar";
            this.enviar.Size = new System.Drawing.Size(90, 34);
            this.enviar.TabIndex = 24;
            this.enviar.Text = "VISA/MC";
            this.enviar.UseVisualStyleBackColor = false;
            this.enviar.Click += new System.EventHandler(this.enviar_Click);
            // 
            // lsecuencia
            // 
            this.lsecuencia.AutoSize = true;
            this.lsecuencia.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lsecuencia.ForeColor = System.Drawing.Color.White;
            this.lsecuencia.Location = new System.Drawing.Point(242, 282);
            this.lsecuencia.Name = "lsecuencia";
            this.lsecuencia.Size = new System.Drawing.Size(67, 13);
            this.lsecuencia.TabIndex = 25;
            this.lsecuencia.Text = "Secuencia";
            // 
            // secuencia
            // 
            this.secuencia.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.secuencia.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.secuencia.Location = new System.Drawing.Point(330, 282);
            this.secuencia.Name = "secuencia";
            this.secuencia.Size = new System.Drawing.Size(100, 20);
            this.secuencia.TabIndex = 26;
            this.secuencia.Text = "20160425S01";
            // 
            // lreferencia
            // 
            this.lreferencia.AutoSize = true;
            this.lreferencia.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lreferencia.ForeColor = System.Drawing.Color.White;
            this.lreferencia.Location = new System.Drawing.Point(6, 281);
            this.lreferencia.Name = "lreferencia";
            this.lreferencia.Size = new System.Drawing.Size(69, 13);
            this.lreferencia.TabIndex = 27;
            this.lreferencia.Text = "Referencia";
            // 
            // referencia
            // 
            this.referencia.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.referencia.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.referencia.Location = new System.Drawing.Point(92, 278);
            this.referencia.Name = "referencia";
            this.referencia.Size = new System.Drawing.Size(132, 20);
            this.referencia.TabIndex = 28;
            this.referencia.Text = "20160425R25";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.button1.Location = new System.Drawing.Point(783, 615);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(88, 30);
            this.button1.TabIndex = 29;
            this.button1.Text = "Salir";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.button2.Location = new System.Drawing.Point(136, 616);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(70, 31);
            this.button2.TabIndex = 30;
            this.button2.Text = "AMEX";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(555, 291);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(43, 13);
            this.label11.TabIndex = 39;
            this.label11.Text = "track1";
            // 
            // track1
            // 
            this.track1.BackColor = System.Drawing.Color.White;
            this.track1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.track1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.track1.Location = new System.Drawing.Point(658, 284);
            this.track1.Name = "track1";
            this.track1.Size = new System.Drawing.Size(178, 20);
            this.track1.TabIndex = 40;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(555, 330);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(43, 13);
            this.label12.TabIndex = 41;
            this.label12.Text = "track2";
            // 
            // track2
            // 
            this.track2.BackColor = System.Drawing.Color.White;
            this.track2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.track2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.track2.Location = new System.Drawing.Point(658, 327);
            this.track2.Name = "track2";
            this.track2.Size = new System.Drawing.Size(222, 20);
            this.track2.TabIndex = 42;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(10, 327);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(65, 13);
            this.label14.TabIndex = 45;
            this.label14.Text = "Promosion";
            // 
            // val_19
            // 
            this.val_19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.val_19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.val_19.Location = new System.Drawing.Point(92, 320);
            this.val_19.Name = "val_19";
            this.val_19.Size = new System.Drawing.Size(30, 20);
            this.val_19.TabIndex = 46;
            this.val_19.Text = "0";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(17, 370);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(38, 13);
            this.label15.TabIndex = 47;
            this.label15.Text = "Plazo";
            // 
            // periodo
            // 
            this.periodo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.periodo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.periodo.Location = new System.Drawing.Point(92, 367);
            this.periodo.Name = "periodo";
            this.periodo.Size = new System.Drawing.Size(30, 20);
            this.periodo.TabIndex = 48;
            this.periodo.Text = "0";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(245, 326);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(59, 13);
            this.label16.TabIndex = 49;
            this.label16.Text = "Tpo Tran";
            // 
            // transaccion
            // 
            this.transaccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.transaccion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.transaccion.Location = new System.Drawing.Point(330, 323);
            this.transaccion.Name = "transaccion";
            this.transaccion.Size = new System.Drawing.Size(30, 20);
            this.transaccion.TabIndex = 50;
            this.transaccion.Text = "1";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(255, 376);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(49, 13);
            this.label17.TabIndex = 51;
            this.label17.Text = "Ingreso";
            // 
            // ingreso
            // 
            this.ingreso.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ingreso.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.ingreso.Location = new System.Drawing.Point(330, 372);
            this.ingreso.Name = "ingreso";
            this.ingreso.Size = new System.Drawing.Size(30, 20);
            this.ingreso.TabIndex = 52;
            this.ingreso.Text = "1";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(12, 456);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(76, 13);
            this.label18.TabIndex = 53;
            this.label18.Text = "autorizacion";
            // 
            // autorizacion
            // 
            this.autorizacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.autorizacion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.autorizacion.Location = new System.Drawing.Point(94, 449);
            this.autorizacion.Name = "autorizacion";
            this.autorizacion.Size = new System.Drawing.Size(70, 20);
            this.autorizacion.TabIndex = 54;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(778, 533);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(35, 13);
            this.label19.TabIndex = 55;
            this.label19.Text = "5F34";
            // 
            // tagE1
            // 
            this.tagE1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tagE1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.tagE1.Location = new System.Drawing.Point(819, 533);
            this.tagE1.Name = "tagE1";
            this.tagE1.Size = new System.Drawing.Size(52, 20);
            this.tagE1.TabIndex = 56;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(22, 499);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(58, 13);
            this.label20.TabIndex = 57;
            this.label20.Text = "TAGEMV";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(186, 548);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(38, 13);
            this.label21.TabIndex = 59;
            this.label21.Text = "FLAG";
            // 
            // flag
            // 
            this.flag.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flag.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.flag.Location = new System.Drawing.Point(233, 545);
            this.flag.Name = "flag";
            this.flag.Size = new System.Drawing.Size(76, 20);
            this.flag.TabIndex = 60;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(555, 536);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(35, 13);
            this.label22.TabIndex = 61;
            this.label22.Text = "9F26";
            // 
            // tag9F26
            // 
            this.tag9F26.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tag9F26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.tag9F26.Location = new System.Drawing.Point(611, 533);
            this.tag9F26.Name = "tag9F26";
            this.tag9F26.Size = new System.Drawing.Size(148, 20);
            this.tag9F26.TabIndex = 62;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(27, 552);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(35, 13);
            this.label23.TabIndex = 63;
            this.label23.Text = "9F27";
            // 
            // tag9F27
            // 
            this.tag9F27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tag9F27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.tag9F27.Location = new System.Drawing.Point(92, 545);
            this.tag9F27.Name = "tag9F27";
            this.tag9F27.Size = new System.Drawing.Size(74, 20);
            this.tag9F27.TabIndex = 64;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.button3.Location = new System.Drawing.Point(233, 618);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(94, 29);
            this.button3.TabIndex = 65;
            this.button3.Text = "AMEX CAN";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(554, 374);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(76, 13);
            this.label24.TabIndex = 66;
            this.label24.Text = "consecutivo";
            // 
            // consecutivo
            // 
            this.consecutivo.BackColor = System.Drawing.Color.White;
            this.consecutivo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.consecutivo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.consecutivo.Location = new System.Drawing.Point(658, 367);
            this.consecutivo.Name = "consecutivo";
            this.consecutivo.Size = new System.Drawing.Size(59, 20);
            this.consecutivo.TabIndex = 67;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.White;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.button4.Location = new System.Drawing.Point(454, 619);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(99, 29);
            this.button4.TabIndex = 68;
            this.button4.Text = "Lee";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // Limpiar
            // 
            this.Limpiar.BackColor = System.Drawing.Color.White;
            this.Limpiar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Limpiar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.Limpiar.Location = new System.Drawing.Point(669, 619);
            this.Limpiar.Name = "Limpiar";
            this.Limpiar.Size = new System.Drawing.Size(90, 30);
            this.Limpiar.TabIndex = 69;
            this.Limpiar.Text = "Limpiar";
            this.Limpiar.UseVisualStyleBackColor = false;
            this.Limpiar.Click += new System.EventHandler(this.Limpiar_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(555, 413);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(89, 13);
            this.label25.TabIndex = 70;
            this.label25.Text = "PLATAFORMA";
            // 
            // plataforma
            // 
            this.plataforma.BackColor = System.Drawing.Color.White;
            this.plataforma.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.plataforma.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.plataforma.Location = new System.Drawing.Point(658, 410);
            this.plataforma.Name = "plataforma";
            this.plataforma.Size = new System.Drawing.Size(59, 20);
            this.plataforma.TabIndex = 71;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.White;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.button6.Location = new System.Drawing.Point(348, 618);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(90, 30);
            this.button6.TabIndex = 73;
            this.button6.Text = "Devolucion";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click_1);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label26.Location = new System.Drawing.Point(133, 312);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(110, 52);
            this.label26.TabIndex = 74;
            this.label26.Text = "0 - Reenvolvente\r\n1- Meses sin Intereres\r\n6-Puntos\r\n7-Sin puntos";
            this.label26.Click += new System.EventHandler(this.label26_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label27.Location = new System.Drawing.Point(383, 370);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(121, 26);
            this.label27.TabIndex = 75;
            this.label27.Text = "0 - Digitada\r\n1- Deslizada o Insertada";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label28.Location = new System.Drawing.Point(180, 456);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(147, 13);
            this.label28.TabIndex = 76;
            this.label28.Text = "Cancelaciones/Devoluciones";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label29.Location = new System.Drawing.Point(733, 374);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(66, 13);
            this.label29.TabIndex = 77;
            this.label29.Text = "Cancelacion";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.White;
            this.label30.Location = new System.Drawing.Point(213, 236);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(73, 13);
            this.label30.TabIndex = 78;
            this.label30.Text = "Tpo Tarjeta";
            // 
            // tpTarjeta
            // 
            this.tpTarjeta.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tpTarjeta.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.tpTarjeta.Location = new System.Drawing.Point(330, 233);
            this.tpTarjeta.Name = "tpTarjeta";
            this.tpTarjeta.Size = new System.Drawing.Size(30, 20);
            this.tpTarjeta.TabIndex = 79;
            this.tpTarjeta.Text = "1";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label31.Location = new System.Drawing.Point(383, 239);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(120, 13);
            this.label31.TabIndex = 80;
            this.label31.Text = "1 - Visa, 2 - Master Card";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label32.Location = new System.Drawing.Point(381, 317);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(99, 39);
            this.label32.TabIndex = 81;
            this.label32.Text = "1- Compra\r\n2- Cancelación\r\n8 - Consulta Puntos";
            // 
            // digest
            // 
            this.digest.BackColor = System.Drawing.Color.White;
            this.digest.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.digest.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.digest.Location = new System.Drawing.Point(658, 449);
            this.digest.Name = "digest";
            this.digest.Size = new System.Drawing.Size(222, 20);
            this.digest.TabIndex = 82;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.Color.White;
            this.label33.Location = new System.Drawing.Point(29, 587);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(24, 13);
            this.label33.TabIndex = 83;
            this.label33.Text = "aid";
            // 
            // aid
            // 
            this.aid.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aid.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.aid.Location = new System.Drawing.Point(92, 580);
            this.aid.Name = "aid";
            this.aid.Size = new System.Drawing.Size(114, 20);
            this.aid.TabIndex = 84;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.White;
            this.label34.Location = new System.Drawing.Point(230, 583);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(41, 13);
            this.label34.TabIndex = 85;
            this.label34.Text = "alabel";
            // 
            // alabel
            // 
            this.alabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.alabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.alabel.Location = new System.Drawing.Point(288, 576);
            this.alabel.Name = "alabel";
            this.alabel.Size = new System.Drawing.Size(100, 20);
            this.alabel.TabIndex = 86;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.White;
            this.label35.Location = new System.Drawing.Point(255, 417);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(87, 13);
            this.label35.TabIndex = 87;
            this.label35.Text = "Ingreso AMEX";
            // 
            // origen
            // 
            this.origen.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.origen.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.origen.Location = new System.Drawing.Point(360, 413);
            this.origen.Name = "origen";
            this.origen.Size = new System.Drawing.Size(51, 20);
            this.origen.TabIndex = 88;
            this.origen.Text = "D@1";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label36.Location = new System.Drawing.Point(428, 413);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(90, 26);
            this.label36.TabIndex = 89;
            this.label36.Text = "D@1 - Deslizada \r\nI@1- Insertada";
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.White;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.button5.Location = new System.Drawing.Point(570, 619);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(90, 30);
            this.button5.TabIndex = 90;
            this.button5.Text = "Termina";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click_2);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.White;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.button7.Location = new System.Drawing.Point(783, 574);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(88, 31);
            this.button7.TabIndex = 91;
            this.button7.Text = "enviar";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(661, 571);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 23);
            this.button8.TabIndex = 92;
            this.button8.Text = "getBines";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click_1);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.White;
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.button9.Location = new System.Drawing.Point(658, 33);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(99, 29);
            this.button9.TabIndex = 93;
            this.button9.Text = "Sincronizar";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.White;
            this.button10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.button10.Location = new System.Drawing.Point(658, 84);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(99, 29);
            this.button10.TabIndex = 94;
            this.button10.Text = "actualizar";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // tagEMV
            // 
            this.tagEMV.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tagEMV.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.tagEMV.Location = new System.Drawing.Point(92, 492);
            this.tagEMV.Name = "tagEMV";
            this.tagEMV.Size = new System.Drawing.Size(744, 20);
            this.tagEMV.TabIndex = 58;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(327, 548);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(36, 13);
            this.label8.TabIndex = 95;
            this.label8.Text = "Serie";
            // 
            // serie
            // 
            this.serie.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.serie.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.serie.Location = new System.Drawing.Point(369, 541);
            this.serie.Name = "serie";
            this.serie.Size = new System.Drawing.Size(180, 20);
            this.serie.TabIndex = 96;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(428, 583);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(78, 13);
            this.label9.TabIndex = 97;
            this.label9.Text = "Mdo Lectura";
            // 
            // mdoLectura
            // 
            this.mdoLectura.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mdoLectura.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.mdoLectura.Location = new System.Drawing.Point(530, 576);
            this.mdoLectura.Name = "mdoLectura";
            this.mdoLectura.Size = new System.Drawing.Size(100, 20);
            this.mdoLectura.TabIndex = 98;
            // 
            // correo
            // 
            this.correo.BackColor = System.Drawing.Color.White;
            this.correo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.correo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.correo.Location = new System.Drawing.Point(661, 131);
            this.correo.Name = "correo";
            this.correo.Size = new System.Drawing.Size(96, 20);
            this.correo.TabIndex = 99;
            // 
            // telefono
            // 
            this.telefono.BackColor = System.Drawing.Color.White;
            this.telefono.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.telefono.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.telefono.Location = new System.Drawing.Point(661, 163);
            this.telefono.Name = "telefono";
            this.telefono.Size = new System.Drawing.Size(96, 20);
            this.telefono.TabIndex = 100;
            // 
            // nombre
            // 
            this.nombre.BackColor = System.Drawing.Color.White;
            this.nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nombre.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.nombre.Location = new System.Drawing.Point(660, 190);
            this.nombre.Name = "nombre";
            this.nombre.Size = new System.Drawing.Size(96, 20);
            this.nombre.TabIndex = 101;
            // 
            // apellidos
            // 
            this.apellidos.BackColor = System.Drawing.Color.White;
            this.apellidos.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apellidos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.apellidos.Location = new System.Drawing.Point(658, 222);
            this.apellidos.Name = "apellidos";
            this.apellidos.Size = new System.Drawing.Size(96, 20);
            this.apellidos.TabIndex = 102;
            // 
            // direccion
            // 
            this.direccion.BackColor = System.Drawing.Color.White;
            this.direccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.direccion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.direccion.Location = new System.Drawing.Point(658, 248);
            this.direccion.Name = "direccion";
            this.direccion.Size = new System.Drawing.Size(96, 20);
            this.direccion.TabIndex = 103;
            // 
            // cdPostal
            // 
            this.cdPostal.BackColor = System.Drawing.Color.White;
            this.cdPostal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cdPostal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.cdPostal.Location = new System.Drawing.Point(775, 131);
            this.cdPostal.Name = "cdPostal";
            this.cdPostal.Size = new System.Drawing.Size(96, 20);
            this.cdPostal.TabIndex = 104;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(132)))));
            this.ClientSize = new System.Drawing.Size(883, 660);
            this.Controls.Add(this.cdPostal);
            this.Controls.Add(this.direccion);
            this.Controls.Add(this.apellidos);
            this.Controls.Add(this.nombre);
            this.Controls.Add(this.telefono);
            this.Controls.Add(this.correo);
            this.Controls.Add(this.mdoLectura);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.serie);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.origen);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.alabel);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.aid);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.digest);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.tpTarjeta);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.plataforma);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.Limpiar);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.consecutivo);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.tag9F27);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.tag9F26);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.flag);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.tagEMV);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.tagE1);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.autorizacion);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.ingreso);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.transaccion);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.periodo);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.val_19);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.track2);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.track1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.referencia);
            this.Controls.Add(this.lreferencia);
            this.Controls.Add(this.secuencia);
            this.Controls.Add(this.lsecuencia);
            this.Controls.Add(this.enviar);
            this.Controls.Add(this.mail);
            this.Controls.Add(this.lmail);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cvv2);
            this.Controls.Add(this.lCVV2);
            this.Controls.Add(this.feccha);
            this.Controls.Add(this.lfecha);
            this.Controls.Add(this.tarjeta);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.titular);
            this.Controls.Add(this.ltitular);
            this.Controls.Add(this.importe);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.moneda);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.servicio);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.nivel1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.entidad);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Multipagos - Bancomer";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox entidad;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox nivel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox servicio;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox moneda;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox importe;
        private System.Windows.Forms.Label ltitular;
        private System.Windows.Forms.TextBox titular;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tarjeta;
        private System.Windows.Forms.Label lfecha;
        private System.Windows.Forms.TextBox feccha;
        private System.Windows.Forms.Label lCVV2;
        private System.Windows.Forms.TextBox cvv2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lmail;
        private System.Windows.Forms.TextBox mail;
        private System.Windows.Forms.Button enviar;
        private System.Windows.Forms.Label lsecuencia;
        private System.Windows.Forms.TextBox secuencia;
        private System.Windows.Forms.Label lreferencia;
        private System.Windows.Forms.TextBox referencia;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox track1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox track2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox val_19;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox periodo;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox transaccion;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox ingreso;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox autorizacion;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox tagE1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox flag;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox tag9F26;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox tag9F27;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox consecutivo;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button Limpiar;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox plataforma;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox tpTarjeta;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox digest;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox aid;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox alabel;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox origen;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.TextBox tagEMV;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox serie;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox mdoLectura;
        private System.Windows.Forms.TextBox correo;
        private System.Windows.Forms.TextBox telefono;
        private System.Windows.Forms.TextBox nombre;
        private System.Windows.Forms.TextBox apellidos;
        private System.Windows.Forms.TextBox direccion;
        private System.Windows.Forms.TextBox cdPostal;
    }
}

